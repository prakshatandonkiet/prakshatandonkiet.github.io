<!-- footer styles -->

<style>.u-footer {
  background-image: ;
  background-position: 50% 50%;
}
.u-footer .u-sheet-1 {
  min-height: 295px;
}
.u-footer .u-image-1 {
  margin: 39px auto 0 43px;
}
.u-footer .u-logo-image-1 {
  max-width: 104px;
  max-height: 104px;
}
.u-footer .u-social-icons-1 {
  height: 23px;
  min-height: 16px;
  width: 122px;
  min-width: 94px;
  white-space: nowrap;
  margin: 21px auto 0 34px;
}
.u-footer .u-icon-1 {
  color: rgb(59, 89, 152) !important;
}
.u-footer .u-icon-2 {
  color: rgb(85, 172, 238) !important;
}
.u-footer .u-icon-3 {
  color: rgb(197, 54, 164) !important;
}
.u-footer .u-icon-4 {
  color: rgb(0, 122, 185) !important;
}
.u-footer .u-line-1 {
  transform-origin: left center 0px;
  width: 1140px;
  margin: 56px auto 60px 0;
}
@media (max-width: 1199px) {
  .u-footer .u-image-1 {
    width: 66px;
    margin-left: 43px;
  }
  .u-footer .u-social-icons-1 {
    margin-left: 420px;
  }
  .u-footer .u-line-1 {
    margin-right: initial;
    margin-left: initial;
    width: auto;
  }
}
@media (max-width: 991px) {
  .u-footer .u-image-1 {
    width: 51px;
  }
  .u-footer .u-social-icons-1 {
    margin-left: auto;
  }
}
@media (max-width: 767px) {
  .u-footer .u-image-1 {
    width: 47px;
  }
}
@media (max-width: 575px) {
  .u-footer .u-image-1 {
    width: auto;
  }
}</style>
